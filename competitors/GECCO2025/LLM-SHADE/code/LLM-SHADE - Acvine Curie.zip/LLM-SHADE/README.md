<h1 align="center">
LLM-SHADE
</h1>
<br>

## 📖 Introduction 

A LLM designed algorithm based on SHADE family.
An EC+LLM framework is utilized to design the algorithm.

## 💻 Example Usage

### Quick Start:

```bash
$ pip install matplotlib openpyxl scipy numpy pandas 
```
In test.py, first set parameters then run.
```python
def main():
    # parallel run 31 runs for run single for 24 problems each
    import multiprocessing
    num_processes = 98  # Set the number of available CPU cores
    total_runs = 31  # Total repeated runs of a single problem
    total_problems = [i+1 for i in range(24)]  # problem index
    # total_problems.append(24)  # 17,18,19,5  20, 24, 22,16,
    random_seed = [i for i in range(total_runs)]  # random seed
    
    with multiprocessing.Pool(processes=num_processes) as pool:
        results = pool.starmap(run_single, [(problem_index, run_index, random_seed[run_index]) for run_index in range(total_runs) for problem_index in total_problems])
    
    # merge all runs results
    for problem_index in total_problems:
        result_path = f'results/problem_{problem_index}/'
        merge_all_runs(result_path, problem_index, total_runs)
        print(f"Results for Problem {problem_index} merged.")

    print(f'Mean Results: {results}, {np.mean(results)}')

    print("All runs completed and results merged.")


if __name__ == "__main__":
    main()
```
```bash
$ python test.py
```